if [ -z "$2" ] ;
then
echo "Not enough parameters"
else
cd $1
# rm *.out || pwd
gcc *.c 
# if [ $3 -eq "-r" ] ;
# then
# find $1 -name "*.out" -type f -delete
 
fi